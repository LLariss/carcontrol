['vehiclecontroller'] = {
	label = 'Vehicle Controller',
	description = 'Adjust your Headlights , Neon Colors and Heights',
	weight = 390,
	stack = false,
	consume = 0,

	client = {
		usetime = 150,
		export = 'renzu_controller.Control'
	}
},