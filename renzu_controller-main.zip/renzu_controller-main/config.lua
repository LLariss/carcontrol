config = {}
config.item = false -- if true, controller need item else standalone
config.keybind = 'HOME'
config.colors = {
	[1] = {label = 'White', r = 222, g = 222, b = 255},
	[2] = {label = 'Electric Blue', r = 2, g = 21, b = 255},
	[3] = {label = 'Mint Green', r = 0, g = 255, b = 140},
	[4] = {label = 'Yellow', r = 255, g = 255, b = 0},
	[5] = {label = 'Orange', r = 255, g = 62, b = 0},
	[6] = {label = 'Red', r = 255, g = 1, b = 1},
	[7] = {label = 'Hot Pink', r = 255, g = 5, b = 190},
}